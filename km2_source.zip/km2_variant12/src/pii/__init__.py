"""PII recognition for KM2."""
from .schema import LABELS, Span
