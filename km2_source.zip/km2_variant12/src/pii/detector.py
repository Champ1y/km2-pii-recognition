from pathlib import Path
from .schema import Span, tokenize, from_bio, resolve
from .rules import structured


class PersonModel:
    """Word-level decisions from first-subtoken logits, overlapping windows."""
    def __init__(self, model_dir="models/person", device=None, batch_size=8):
        import torch
        from transformers import AutoModelForTokenClassification, AutoTokenizer
        self.torch = torch
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(str(model_dir), local_files_only=True)
        self.model = AutoModelForTokenClassification.from_pretrained(str(model_dir), local_files_only=True).to(self.device).eval()
        self.batch_size = batch_size

    def predict_many(self, texts):
        torch = self.torch
        token_lists = [tokenize(t) for t in texts]
        result = []
        for tokens in token_lists:
            if not tokens:
                result.append([]); continue
            enc = self.tokenizer([t[0] for t in tokens], is_split_into_words=True,
                                 truncation=True, max_length=256, stride=48,
                                 return_overflowing_tokens=True, padding=True, return_tensors="pt")
            best = {}
            for start in range(0, len(enc["input_ids"]), self.batch_size):
                batch = {k: v[start:start+self.batch_size].to(self.device) for k,v in enc.items() if k in ("input_ids","attention_mask","token_type_ids")}
                with torch.inference_mode():
                    logits = self.model(**batch).logits.float().cpu()
                for k, scores in enumerate(logits):
                    ids = enc.word_ids(start+k)
                    for i,wid in enumerate(ids):
                        if wid is None or (i>0 and ids[i-1]==wid): continue
                        # Prefer the window where the word lies farthest from an edge.
                        centrality = min(i, int(enc["attention_mask"][start+k].sum())-1-i)
                        if wid not in best or centrality > best[wid][0]:
                            best[wid] = (centrality, self.model.config.id2label[int(scores[i].argmax())])
            tags = [best.get(i,(0,"O"))[1] for i in range(len(tokens))]
            result.append(from_bio(tokens,tags))
        return result

    def __call__(self,text):
        return self.predict_many([text])[0]


class HybridDetector:
    def __init__(self, model_dir="models/person", device=None, rules_only=False):
        self.person = None if rules_only else PersonModel(model_dir,device)

    def predict_many(self,texts):
        person = self.person.predict_many(texts) if self.person else [[] for _ in texts]
        return [resolve(structured(text)+p) for text,p in zip(texts,person)]

    def __call__(self,text):
        if not isinstance(text,str): raise TypeError("text must be str")
        return self.predict_many([text])[0]

    def recognize(self,text):
        return [s.triple() for s in self(text)]
