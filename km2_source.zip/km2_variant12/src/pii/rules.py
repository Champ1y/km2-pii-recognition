"""Deterministic candidates; checksum validity is not registry existence."""
import ipaddress
import re
from .schema import Span, resolve


def digits(s):
    return "".join(c for c in s if c in "0123456789")


def inn_complete(base):
    def check(v, w):
        return str(sum(int(a)*b for a, b in zip(v, w)) % 11 % 10)
    if len(base) == 9:
        return base + check(base, (2,4,10,3,5,9,4,6,8))
    if len(base) == 10:
        first = base + check(base, (7,2,4,10,3,5,9,4,6,8))
        return first + check(first, (3,7,2,4,10,3,5,9,4,6,8))
    raise ValueError("INN base must have 9 or 10 digits")


def valid_inn(s):
    s = digits(s)
    return len(s) in (10,12) and len(set(s)) > 1 and inn_complete(s[:-1] if len(s)==10 else s[:-2]) == s


def valid_ogrnip(s):
    return len(s)==15 and s.isascii() and s.isdigit() and s[0] in "34" and int(s[3:5]) in range(1,100) and int(s[-1]) == int(s[:-1]) % 13 % 10


def luhn_sum(s):
    return sum((2*int(c)-9 if 2*int(c)>9 else 2*int(c)) if i%2 else int(c) for i,c in enumerate(s[::-1]))


def valid_card(s):
    s = digits(s)
    return 13 <= len(s) <= 19 and len(set(s))>1 and luhn_sum(s)%10==0


def complete_card(base):
    return base + str((-luhn_sum(base+"0")) % 10)


EMAIL = re.compile(r"(?<![\w.+-])[\w]+(?:[.+-][\w]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[a-zа-яё]{2,63}(?![\w-])", re.I)
IPV4 = re.compile(r"(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?!\w|\.\d)")
IPV6 = re.compile(r"(?<![\w:])(?:[0-9a-f]{0,4}:){2,7}[0-9a-f]{0,4}(?![\w:])", re.I)
INN = re.compile(r"(?<!\d)(?:\d{12}|\d{10})(?!\d)")
OGRNIP = re.compile(r"(?<!\d)[34]\d{14}(?!\d)")
CARD = re.compile(r"(?<!\d)\d(?:[ -]?\d){12,18}(?![ -]?\d)")
PASSPORT = re.compile(r"(?<!\d)(?:\d{2}[ ]?\d{2})[ ]\d{6}(?!\d)")
BIRTH = re.compile(r"(?<![\w])[IVXLCDMІ]{1,6}[-–][А-ЯЁ]{2}\s*(?:№\s*)?\d{6}(?!\d)")
KLADR = re.compile(r"(?<!\d)(?:\d{19}|\d{17}|\d{13})(?!\d)")


def structured(text):
    out = []
    def add(label, match):
        out.append(Span(label, match.start(), match.end()))
    for m in EMAIL.finditer(text): add("EMAIL", m)
    for pattern in (IPV4, IPV6):
        for m in pattern.finditer(text):
            try: ipaddress.ip_address(m.group())
            except ValueError: continue
            add("IP", m)
    for m in BIRTH.finditer(text):
        context = text[max(0,m.start()-80):m.start()].lower()
        if "брак" not in context or "рожд" in context: add("BIRTH_CERT", m)
    for m in KLADR.finditer(text):
        if re.search(r"кладр\s*[:=№-]?\s*$", text[max(0,m.start()-35):m.start()], re.I) and 1<=int(m.group()[:2])<=99:
            add("KLADR", m)
    for m in OGRNIP.finditer(text):
        if valid_ogrnip(m.group()): add("OGRNIP", m)
    for m in INN.finditer(text):
        if valid_inn(m.group()): add("INN", m)
    for m in CARD.finditer(text):
        # More specific numbered documents are resolved before card candidates.
        if re.search(r"(?:огрнип|инн|кладр)\s*[:=№]?\s*$",text[max(0,m.start()-30):m.start()],re.I):continue
        if valid_card(m.group()): add("BANK_CARD", m)
    for m in PASSPORT.finditer(text):
        if 1<=int(digits(m.group())[:2])<=99: add("PASSPORT", m)
    # Contiguous passport numbers require a nearby explicit document label.
    for m in re.finditer(r"(?<!\d)\d{10}(?!\d)", text):
        if re.search(r"паспорт(?:а|ом)?\s*[:№]?\s*$", text[max(0,m.start()-30):m.start()], re.I) and 1<=int(m.group()[:2])<=99:
            add("PASSPORT",m)
    return resolve(out)
