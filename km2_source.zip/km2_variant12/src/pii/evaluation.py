import time
from collections import Counter
from sklearn.metrics import classification_report, confusion_matrix
from .schema import LABELS, to_bio


def counts_metrics(tp,fp,fn):
    p=tp/(tp+fp) if tp+fp else 0.0
    r=tp/(tp+fn) if tp+fn else 0.0
    return {"tp":tp,"fp":fp,"fn":fn,"support":tp+fn,"precision":p,"recall":r,"f1":2*p*r/(p+r) if p+r else 0.0}


def evaluate(rows,predictions):
    if len(rows)!=len(predictions):raise ValueError("Mismatched prediction count")
    gold_tags=[];pred_tags=[];gold_attr=[];pred_attr=[];errors=[]
    entity_counts={l:Counter() for l in LABELS}
    for row,pred in zip(rows,predictions):
        _,g=to_bio(row["text"],row["entities"]);_,p=to_bio(row["text"],pred)
        gold_tags.extend(g);pred_tags.extend(p)
        gold_attr.extend(t.split("-",1)[1] if t!="O" else "O" for t in g)
        pred_attr.extend(t.split("-",1)[1] if t!="O" else "O" for t in p)
        gs={tuple(x) for x in row["entities"]};ps={tuple(x.triple()) for x in pred}
        for label in LABELS:
            gl={s for s in gs if s[0]==label};pl={s for s in ps if s[0]==label}
            entity_counts[label].update(tp=len(gl&pl),fp=len(pl-gl),fn=len(gl-pl))
        if gs!=ps:
            errors.append({"id":row["id"],"source":row["source"],"text":row["text"],"false_positive":[list(s) for s in sorted(ps-gs)],"false_negative":[list(s) for s in sorted(gs-ps)]})
    bio_labels=[p+l for l in LABELS for p in ("B-","I-") if p+l in set(gold_tags)]
    # Labels with zero gold support are still included if predicted, to expose FPs.
    predicted_only=sorted(set(pred_tags)-set(gold_tags)-{"O"})
    bio_labels+=predicted_only
    token=classification_report(gold_tags,pred_tags,labels=bio_labels,output_dict=True,zero_division=0)
    attribute=classification_report(gold_attr,pred_attr,labels=list(LABELS),output_dict=True,zero_division=0)
    exact={l:counts_metrics(c["tp"],c["fp"],c["fn"]) for l,c in entity_counts.items()}
    overall=counts_metrics(sum(x["tp"] for x in exact.values()),sum(x["fp"] for x in exact.values()),sum(x["fn"] for x in exact.values()))
    per_label={}
    for l in LABELS:
        tp=sum(g==l and p==l for g,p in zip(gold_attr,pred_attr))
        fp=sum(g!=l and p==l for g,p in zip(gold_attr,pred_attr))
        fn=sum(g==l and p!=l for g,p in zip(gold_attr,pred_attr))
        per_label[l]=counts_metrics(tp,fp,fn)
    metrics={"documents":len(rows),"tokens":len(gold_tags),"main_metric":"BIO token classification, O excluded from averaging; O positions retained", "bio":token,"attribute_tokens":attribute,"per_attribute":per_label,"exact_entities":exact,"exact_micro":overall,"documents_with_errors":len(errors),"thresholds":{"weighted_required":0.85,"macro_required":0.8,"passed":token["weighted avg"]["f1-score"]>=0.85 and token["macro avg"]["f1-score"]>=0.8},"confusion_labels":["O"]+list(LABELS),"confusion_matrix":confusion_matrix(gold_attr,pred_attr,labels=["O"]+list(LABELS)).tolist()}
    return metrics,errors
