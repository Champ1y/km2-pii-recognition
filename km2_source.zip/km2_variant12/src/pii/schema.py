import json
import math
import re
from dataclasses import dataclass
from pathlib import Path

LABELS = ("SURNAME", "NAME", "INN", "PASSPORT", "BANK_CARD", "OGRNIP", "IP", "EMAIL", "BIRTH_CERT", "KLADR")
RUSSIAN = dict(zip(LABELS, ("Фамилия", "Имя", "ИНН", "Паспорт", "Банковская карта", "ОГРНИП", "IP-адрес", "Электронная почта", "Свидетельство о рождении", "Код КЛАДР")))
TOKEN_RE = re.compile(r"[^\W\d_]+(?:[-‐‑][^\W\d_]+)*|\d+|[^\w\s]", re.UNICODE)


@dataclass(frozen=True)
class Span:
    label: str
    start: int
    end: int
    score: float = 1.0
    source: str = "rule"

    def triple(self):
        return [self.label, self.start, self.end]


def tokenize(text):
    if not isinstance(text, str):
        raise TypeError("text must be str")
    return [(m.group(), m.start(), m.end()) for m in TOKEN_RE.finditer(text)]


def validate_spans(text, spans):
    if not isinstance(text, str):
        raise TypeError("text must be str")
    result = []
    for item in spans:
        s = item if isinstance(item, Span) else Span(*item)
        if s.label not in LABELS:
            raise ValueError(f"Unknown label: {s.label}")
        if type(s.start) is not int or type(s.end) is not int or not 0 <= s.start < s.end <= len(text):
            raise ValueError("Invalid source coordinates")
        result.append(s)
    result.sort(key=lambda s: (s.start, s.end))
    if any(a.end > b.start for a, b in zip(result, result[1:])):
        raise ValueError("Overlapping source intervals")
    return result


def to_bio(text, spans):
    tokens = tokenize(text)
    tags = ["O"] * len(tokens)
    for s in validate_spans(text, spans):
        ids = [i for i, (_, a, b) in enumerate(tokens) if a < s.end and b > s.start]
        if not ids or tokens[ids[0]][1] != s.start or tokens[ids[-1]][2] != s.end:
            raise ValueError(f"Span is not aligned with evaluation tokens: {s}")
        for j, i in enumerate(ids):
            tags[i] = ("B-" if j == 0 else "I-") + s.label
    return tokens, tags


def from_bio(tokens, tags, source="model"):
    result = []
    active = None
    for (_, a, b), tag in zip(tokens, tags):
        if tag == "O":
            active = None
            continue
        prefix, label = tag.split("-", 1)
        if prefix == "I" and active is not None and result[active].label == label:
            old = result[active]
            result[active] = Span(label, old.start, b, source=source)
        else:
            result.append(Span(label, a, b, source=source))
            active = len(result) - 1
    return result


def resolve(candidates):
    # Structured candidates outrank any model fragments; ties prefer specific,
    # confident and longer intervals. Every character is assigned at most once.
    priority = {"EMAIL": 100, "BIRTH_CERT": 95, "IP": 90, "KLADR": 85,
                "OGRNIP": 80, "INN": 75, "BANK_CARD": 70, "PASSPORT": 65}
    accepted = []
    for s in sorted(set(candidates), key=lambda s: (-priority.get(s.label, 0), -s.score, -(s.end-s.start), s.start)):
        if all(s.end <= x.start or x.end <= s.start for x in accepted):
            accepted.append(s)
    return sorted(accepted, key=lambda s: s.start)


def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    def finite(x):
        if isinstance(x,float) and not math.isfinite(x):return None
        if isinstance(x,dict):return {k:finite(v) for k,v in x.items()}
        if isinstance(x,(list,tuple)):return [finite(v) for v in x]
        return x
    path.write_text(json.dumps(finite(value), ensure_ascii=False, indent=2,allow_nan=False), encoding="utf-8")


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
