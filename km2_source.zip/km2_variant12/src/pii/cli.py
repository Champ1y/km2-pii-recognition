import argparse
import json
from pathlib import Path
from .detector import HybridDetector

def main():
    parser=argparse.ArgumentParser(description="Распознавание ПДн для КМ2, вариант 12")
    parser.add_argument("command",choices=["recognize"])
    parser.add_argument("--text")
    parser.add_argument("--input",type=Path)
    parser.add_argument("--output",type=Path)
    parser.add_argument("--model",default="models/person")
    parser.add_argument("--device",choices=["cpu","cuda"])
    args=parser.parse_args()
    if (args.text is None)==(args.input is None):parser.error("Specify one of --text or --input")
    text=args.text if args.text is not None else args.input.read_text(encoding="utf-8")
    result={"entities":HybridDetector(args.model,args.device).recognize(text)}
    payload=json.dumps(result,ensure_ascii=False,indent=2)
    if args.output:args.output.write_text(payload,encoding="utf-8")
    else:print(payload)

if __name__=="__main__":main()
