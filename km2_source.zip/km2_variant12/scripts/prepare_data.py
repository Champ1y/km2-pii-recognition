"""Independent gold annotation by source spans / insertion offsets, never detector."""
import hashlib
import random
import re
import sys
import urllib.request
import zipfile
from collections import Counter
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from pii.schema import LABELS, Span, resolve, to_bio, write_json, write_jsonl
from pii.rules import inn_complete, complete_card
from functools import lru_cache

@lru_cache(maxsize=1)
def morph():
    import pymorphy3
    return pymorphy3.MorphAnalyzer()

ROOT=Path(__file__).resolve().parents[1]


def fact_documents(folder):
    rows=[]
    conflicts=[]
    for f in sorted(folder.glob("book_*.txt")):
        text=f.read_text(encoding="utf-8-sig")
        persons=set()
        for line in f.with_suffix(".objects").read_text(encoding="utf-8-sig").splitlines():
            fields=line.split("#",1)[0].split()
            if len(fields)>2 and fields[1]=="Person": persons.update(fields[2:])
        spans=[]
        for line in f.with_suffix(".spans").read_text(encoding="utf-8-sig").splitlines():
            fields=line.split("#",1)[0].split()
            if len(fields)<4 or fields[0] not in persons or fields[1] not in ("name","surname"): continue
            start,length=map(int,fields[2:4])
            spans.append(Span("NAME" if fields[1]=="name" else "SURNAME",start,start+length,source="gold"))
        spans=sorted(set(spans),key=lambda s:(s.start,s.end,s.label))
        selected=resolve(spans)
        # Keep every document, explicitly document unavoidable overlap resolution.
        if len(spans)!=len(selected): conflicts.append({"id":f.stem,"before":len(spans),"after":len(selected)})
        # Character tokens sometimes include a source annotation covering only one
        # half of a hyphenated word. Such spans are expanded to evaluation tokens.
        from pii.schema import tokenize
        toks=tokenize(text)
        aligned=[]
        for s in selected:
            ts=[(a,b) for _,a,b in toks if a<s.end and b>s.start]
            if ts: aligned.append(Span(s.label,ts[0][0],ts[-1][1],source="gold"))
        aligned=resolve(aligned)
        to_bio(text,aligned)
        rows.append({"id":f"fact_{folder.name}_{f.stem}","source":"factRuEval2016","text":text,"entities":[s.triple() for s in aligned]})
    return rows,conflicts


def render(template,values):
    text="";spans=[]
    for part in re.split(r"(\{[A-Z_]+\})",template):
        if part.startswith("{") and part.endswith("}"):
            label=part[1:-1];v=values[label]
            start=len(text);text+=v;spans.append([label,start,len(text)])
        else:text+=part
    return text,spans


TEMPLATES={
"train":[
"{NAME} {SURNAME} подал заявление. ИНН {INN}; паспорт {PASSPORT}; карта {BANK_CARD}. ОГРНИП {OGRNIP}, IP {IP}, почта {EMAIL}. Свидетельство о рождении {BIRTH_CERT}. Код КЛАДР {KLADR}.",
"Мы получили письмо от {NAME} {SURNAME}. В нём указаны ИНН: {INN}, паспорт: {PASSPORT}, e-mail: {EMAIL}, IP: {IP}. Карта {BANK_CARD}; ОГРНИП {OGRNIP}. Свидетельство о рождении: {BIRTH_CERT}; КЛАДР: {KLADR}.",
"Обращение направлено к {NAME} {SURNAME}. Реквизиты: ИНН {INN}, карта {BANK_CARD}, паспорт {PASSPORT}, ОГРНИП {OGRNIP}. Адрес почты {EMAIL}, IP {IP}. Свидетельство о рождении {BIRTH_CERT}; код КЛАДР {KLADR}.",
"Мы говорили о {NAME} {SURNAME}. Паспорт {PASSPORT}; ИНН {INN}; ОГРНИП {OGRNIP}. Для оплаты используется карта {BANK_CARD}. Контакт: {EMAIL}; сервер {IP}. Свидетельство о рождении {BIRTH_CERT}. КЛАДР {KLADR}.",
"Документы подписаны {NAME} {SURNAME}. Паспорт {PASSPORT}, карта {BANK_CARD}, ИНН {INN}, ОГРНИП {OGRNIP}, e-mail {EMAIL}, IP {IP}, свидетельство о рождении {BIRTH_CERT}, КЛАДР {KLADR}.",
],
"validation":[
"Заявитель {SURNAME} {NAME} уточнил сведения. Паспорт: {PASSPORT}; ИНН: {INN}; карта: {BANK_CARD}. ОГРНИП: {OGRNIP}; адрес {EMAIL}; IP {IP}; свидетельство о рождении {BIRTH_CERT}; КЛАДР {KLADR}.",
"По запросу {NAME} {SURNAME} подготовлена выписка: ИНН {INN}, ОГРНИП {OGRNIP}, паспорт {PASSPORT}, банковская карта {BANK_CARD}. Почта {EMAIL}, IP {IP}. Свидетельство о рождении {BIRTH_CERT}; код КЛАДР {KLADR}.",
],
"test":[
"Получатель уведомления — {NAME} {SURNAME}. В карточке клиента записаны паспорт {PASSPORT} и ИНН {INN}. Платёжная карта: {BANK_CARD}; регистрационный ОГРНИП: {OGRNIP}. Ответ направить на {EMAIL}. Соединение с {IP}. Свидетельство о рождении {BIRTH_CERT}; код КЛАДР {KLADR}.",
"Для {NAME} {SURNAME} сформирован договор. Его реквизиты перечислены ниже:\nИНН={INN}; ОГРНИП={OGRNIP}\nПаспорт {PASSPORT}\nКарта {BANK_CARD}\nEmail {EMAIL}\nIP {IP}\nСвидетельство о рождении {BIRTH_CERT}\nКЛАДР={KLADR}",
"Информация о {NAME} {SURNAME} передана оператору. Приложены паспорт {PASSPORT}, свидетельство о рождении {BIRTH_CERT}, ИНН {INN}, ОГРНИП {OGRNIP}. Указаны карта {BANK_CARD}, почта {EMAIL}, IP {IP} и код КЛАДР {KLADR}.",
"Заявление принято от {NAME} {SURNAME}; обработка займёт два дня. Для сверки: паспорт {PASSPORT}, ИНН {INN}, ОГРНИП {OGRNIP}. Банковская карта {BANK_CARD}. Уведомление: {EMAIL}, источник запроса {IP}. Свидетельство о рождении {BIRTH_CERT}, КЛАДР {KLADR}.",
"Сотрудник встретился с {NAME} {SURNAME} и проверил карточку. ИНН {INN}; паспорт {PASSPORT}; ОГРНИП {OGRNIP}; карта {BANK_CARD}; электронный адрес {EMAIL}; IP-адрес {IP}; свидетельство о рождении {BIRTH_CERT}; КЛАДР {KLADR}.",
"{SURNAME} {NAME} подтвердил получение заказа. В анкете содержатся ИНН {INN}, паспорт {PASSPORT}, карта {BANK_CARD}, ОГРНИП {OGRNIP}, e-mail {EMAIL}, IP {IP}, свидетельство о рождении {BIRTH_CERT} и код КЛАДР {KLADR}.",
]}
CASES={"train":["nomn","gent","datv","loct","ablt"],"validation":["nomn","gent"],"test":["nomn","gent","loct","gent","ablt","nomn"]}


def synthetic(split,n,seed):
    from faker import Faker
    rng=random.Random(seed);fake=Faker("ru_RU");fake.seed_instance(seed)
    rows=[]
    def number(k):return "".join(rng.choice("0123456789") for _ in range(k))
    for i in range(n):
        j=i%len(TEMPLATES[split]);case=CASES[split][j];female=i%2==0
        name=fake.first_name_female() if female else fake.first_name_male()
        surname=fake.last_name_female() if female else fake.last_name_male()
        for key,v in (("name",name),("surname",surname)):
            ps=[p for p in morph().parse(v) if ("Name" if key=="name" else "Surn") in p.tag]
            p=(ps or morph().parse(v))[0];form=p.inflect({case})
            if key=="name":name=(form.word if form else v).title()
            else:surname=(form.word if form else v).title()
        tax=rng.choice(("7701","7802","5003","6604"))
        inn=inn_complete(tax+number(6))
        base="3"+str(rng.randrange(10,26))+rng.choice(("77","78","50","66"))+number(9)
        ogrnip=base+str(int(base)%13%10)
        card=complete_card(rng.choice(("427600","546900","220220"))+number(9))
        # Different layouts are balanced across splits.
        card=" ".join(card[k:k+4] for k in range(0,16,4)) if i%3 else card
        passport=rng.choice(("45","40","46","65"))+str(rng.randrange(10,26))+" "+number(6)
        if i%3==1:passport=passport[:2]+" "+passport[2:]
        ip=f"{rng.randrange(10,220)}.{rng.randrange(256)}.{rng.randrange(256)}.{rng.randrange(1,255)}" if i%7 else f"2001:db8:{rng.randrange(65536):x}::{rng.randrange(1,65536):x}"
        length=(13,17,19)[i%3]
        kladr=rng.choice(("77","78","50","66"))+number(length-4)+"00"
        values={"NAME":name,"SURNAME":surname,"INN":inn,"PASSPORT":passport,"BANK_CARD":card,"OGRNIP":ogrnip,"IP":ip,"EMAIL":f"client{seed}{i}.info@"+rng.choice(("example.org","mail.ru","example.com")),"BIRTH_CERT":rng.choice(("IV","II","VI"))+"-"+rng.choice(("МЮ","АГ","МУ"))+" № "+number(6),"KLADR":kladr}
        text,spans=render(TEMPLATES[split][j],values)
        # Avoid a gender-inconsistent surrounding verb in the final test template.
        if female and "подтвердил" in text:text=text.replace("подтвердил","подтвердила")
        # That replacement lies after both person spans and before structured data:
        # regenerate offsets after altering the template, not from a recognizer.
        template=TEMPLATES[split][j].replace("подтвердил","подтвердила") if female else TEMPLATES[split][j]
        text,spans=render(template,values)
        to_bio(text,spans)
        rows.append({"id":f"synthetic_{split}_{i:04d}","source":"synthetic","template":f"{split}_{j}","text":text,"entities":spans})
    return rows


def negatives(split,n,seed):
    rng=random.Random(seed)
    rows=[]
    templates=["Вчера завершён проект; номер заявки {v}. Персональные сведения отсутствуют.","Мы прочитали интересный роман. Надежда на успех сохраняется. Вера в результат важна.","IP: 999.12.34.56. ИНН: {bad}. Номер не прошёл проверку.","ОГРНИП {ogrn}. Это испорченная запись."]
    for i in range(n):
        base="7701"+"".join(rng.choice("0123456789") for _ in range(6));valid=inn_complete(base)
        bad=valid[:-1]+str((int(valid[-1])+1)%10)
        obase="32477"+"".join(rng.choice("0123456789") for _ in range(9))
        ogrn=obase+str((int(obase)%13%10+1)%10)
        # Do not accidentally make the invalid OGRNIP a valid card number.
        from pii.rules import valid_card
        if valid_card(ogrn): ogrn=obase+str((int(obase)%13%10+2)%10)
        text=templates[i%len(templates)].format(v=rng.randrange(100,999999),bad=bad,ogrn=ogrn)+f" Проверка {seed}-{i}."
        rows.append({"id":f"negative_{split}_{i}","source":"negative","text":text,"entities":[]})
    return rows


def main():
    raw=ROOT/"data/raw";raw.mkdir(parents=True,exist_ok=True)
    archive=raw/"factRuEval-master.zip"
    if not archive.exists():urllib.request.urlretrieve("https://codeload.github.com/dialogue-evaluation/factRuEval-2016/zip/refs/heads/master",archive)
    folder=raw/"factRuEval-2016-master"
    if not folder.exists():
        with zipfile.ZipFile(archive) as z:z.extractall(raw)
    dev,dc=fact_documents(folder/"devset");test,tc=fact_documents(folder/"testset")
    rng=random.Random(20261124);rng.shuffle(dev);cut=int(len(dev)*0.8)
    splits={"train":dev[:cut]+synthetic("train",800,12001)+negatives("train",80,12002),
            "validation":dev[cut:]+synthetic("validation",120,12003)+negatives("validation",24,12004),
            "test":test+synthetic("test",240,12005)+negatives("test",48,12006)}
    stats={"seed":20261124,"fact_archive_sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"annotation":"Person name/surname spans; other classes inserted with independent offsets", "overlap_resolution":dc+tc,"splits":{}}
    for split,rows in splits.items():
        seen=set();unique=[]
        for row in rows:
            if row["text"] in seen:continue
            seen.add(row["text"]);unique.append(row)
        splits[split]=unique
        write_jsonl(ROOT/f"data/{split}.jsonl",unique)
        counts=Counter(s[0] for row in unique for s in row["entities"])
        docs=Counter(l for row in unique for l in {s[0] for s in row["entities"]})
        stats["splits"][split]={"documents":len(unique),"sources":dict(Counter(x["source"] for x in unique)),"entities":dict(counts),"documents_per_label":dict(docs),"sha256":hashlib.sha256((ROOT/f"data/{split}.jsonl").read_bytes()).hexdigest()}
    cross=[]
    for a,b in (("train","validation"),("train","test"),("validation","test")):
        overlap={x["text"] for x in splits[a]}&{x["text"] for x in splits[b]}
        cross.append({"splits":[a,b],"duplicate_texts":len(overlap)})
        assert not overlap,(a,b)
    stats["cross_split_checks"]=cross
    assert len(splits["test"])>=100
    assert all(stats["splits"]["test"]["entities"].get(l,0)>=50 for l in LABELS)
    write_json(ROOT/"data/dataset_stats.json",stats)
    print(stats["splits"])


if __name__=="__main__":main()
