import csv
import hashlib
import json
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from pii.schema import LABELS,read_jsonl,write_json,write_jsonl
from pii.detector import HybridDetector
from pii.evaluation import evaluate
from pii.rules import structured


def main():
    import torch
    torch.set_num_threads(4)
    root=Path(__file__).resolve().parents[1]
    rows=read_jsonl(root/"data/test.jsonl")
    detector=HybridDetector(root/"models/person")
    preds=[];start=time.time()
    for i,row in enumerate(rows):
        preds.append(detector(row["text"]))
        if (i+1)%25==0:print(f"Detected {i+1}/{len(rows)}, {time.time()-start:.1f}s",flush=True)
    metrics,errors=evaluate(rows,preds)
    metrics["elapsed_seconds"]=time.time()-start
    metrics["test_sha256"]=hashlib.sha256((root/"data/test.jsonl").read_bytes()).hexdigest()
    metrics["model_sha256"]=hashlib.sha256((root/"models/person/model.safetensors").read_bytes()).hexdigest()
    write_json(root/"results/recognition.json",metrics)
    write_jsonl(root/"results/recognition_errors.jsonl",errors)
    write_jsonl(root/"results/predictions.jsonl",[{"id":r["id"],"entities":[s.triple() for s in p]} for r,p in zip(rows,preds)])
    subsets={}
    for source in ("factRuEval2016","synthetic","negative"):
        ids=[i for i,r in enumerate(rows) if r["source"]==source]
        subsets[source]=evaluate([rows[i] for i in ids],[preds[i] for i in ids])[0]
    write_json(root/"results/recognition_subsets.json",subsets)
    baseline,_=evaluate(rows,[structured(r["text"]) for r in rows])
    write_json(root/"results/rules_only.json",baseline)
    with (root/"results/recognition_per_attribute.csv").open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.writer(f);w.writerow(["attribute","TP","FP","FN","support","precision","recall","F1"])
        for l in LABELS:
            m=metrics["per_attribute"][l];w.writerow([l]+[m[k] for k in ("tp","fp","fn","support","precision","recall","f1")])
    print(json.dumps({"bio_weighted":metrics["bio"]["weighted avg"],"bio_macro":metrics["bio"]["macro avg"],"per_attribute":metrics["per_attribute"],"thresholds":metrics["thresholds"]},ensure_ascii=False,indent=2),flush=True)


if __name__=="__main__":main()
