import argparse
import copy
import hashlib
import json
import random
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from pii.schema import read_jsonl,to_bio,write_json

BASE="DeepPavlov/rubert-base-cased"
TAGS=["O","B-NAME","I-NAME","B-SURNAME","I-SURNAME"]


def main():
    import numpy as np
    import torch
    from torch.utils.data import DataLoader
    from transformers import AutoTokenizer,AutoModelForTokenClassification,DataCollatorForTokenClassification,get_linear_schedule_with_warmup
    from sklearn.metrics import f1_score
    parser=argparse.ArgumentParser();parser.add_argument("--epochs",type=int,default=8);parser.add_argument("--batch-size",type=int,default=4);parser.add_argument("--lr",type=float,default=5e-5);parser.add_argument("--train-layers",type=int,default=4);args=parser.parse_args()
    torch.set_num_threads(4)
    random.seed(12012);np.random.seed(12012);torch.manual_seed(12012)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(12012)
    device="cuda" if torch.cuda.is_available() else "cpu"
    root=Path(__file__).resolve().parents[1]
    tokenizer=AutoTokenizer.from_pretrained(BASE,use_fast=True)
    model=AutoModelForTokenClassification.from_pretrained(BASE,num_labels=len(TAGS),id2label=dict(enumerate(TAGS)),label2id={x:i for i,x in enumerate(TAGS)})
    for p in model.bert.embeddings.parameters():p.requires_grad=False
    for layer in model.bert.encoder.layer[:-args.train_layers]:
        for p in layer.parameters():p.requires_grad=False
    model.to(device)
    def encode(rows):
        result=[]
        for row in rows:
            spans=[s for s in row["entities"] if s[0] in ("NAME","SURNAME")]
            tokens,tags=to_bio(row["text"],spans)
            if not tokens:continue
            enc=tokenizer([t[0] for t in tokens],is_split_into_words=True,truncation=True,max_length=256,stride=48,return_overflowing_tokens=True)
            for i in range(len(enc["input_ids"])):
                ids=enc.word_ids(i);labels=[]
                for k,w in enumerate(ids):
                    labels.append(-100 if w is None or (k>0 and ids[k-1]==w) else TAGS.index(tags[w]))
                result.append({**{k:enc[k][i] for k in ("input_ids","attention_mask","token_type_ids") if k in enc},"labels":labels})
        return result
    train=encode(read_jsonl(root/"data/train.jsonl"));val=encode(read_jsonl(root/"data/validation.jsonl"))
    collator=DataCollatorForTokenClassification(tokenizer,pad_to_multiple_of=8)
    loader=DataLoader(train,batch_size=args.batch_size,shuffle=True,collate_fn=collator,num_workers=0)
    vloader=DataLoader(val,batch_size=8,shuffle=False,collate_fn=collator,num_workers=0)
    optimizer=torch.optim.AdamW((p for p in model.parameters() if p.requires_grad),lr=args.lr,weight_decay=.01)
    total=(len(loader)+1)//2*args.epochs
    scheduler=get_linear_schedule_with_warmup(optimizer,int(total*.1),total)
    scaler=torch.amp.GradScaler("cuda",enabled=device=="cuda")
    best=-1.;history=[];start=time.time()
    dest=root/"models/person";dest.mkdir(parents=True,exist_ok=True)
    print(json.dumps({"device":device,"train_windows":len(train),"validation_windows":len(val),"trainable_parameters":sum(p.numel() for p in model.parameters() if p.requires_grad),"configuration":vars(args)}),flush=True)
    for epoch in range(args.epochs):
        model.train();losses=[];optimizer.zero_grad(set_to_none=True)
        for step,batch in enumerate(loader):
            batch={k:v.to(device) for k,v in batch.items()}
            with torch.autocast(device_type=device,dtype=torch.float16,enabled=device=="cuda"):
                loss=model(**batch).loss/2
            scaler.scale(loss).backward();losses.append(float(loss.detach())*2)
            if step%2==1 or step==len(loader)-1:
                scaler.unscale_(optimizer);torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
                scaler.step(optimizer);scaler.update();scheduler.step();optimizer.zero_grad(set_to_none=True)
            if (step+1)%100==0: print(f"epoch {epoch+1} step {step+1}/{len(loader)} loss {sum(losses[-100:])/len(losses[-100:]):.4f}",flush=True)
        model.eval();gold=[];pred=[]
        with torch.inference_mode():
            for batch in vloader:
                labels=batch.pop("labels")
                out=model(**{k:v.to(device) for k,v in batch.items()}).logits.argmax(-1).cpu()
                mask=labels!=-100;gold.extend(labels[mask].tolist());pred.extend(out[mask].tolist())
        wf=f1_score(gold,pred,labels=list(range(1,len(TAGS))),average="weighted",zero_division=0)
        mf=f1_score(gold,pred,labels=sorted(set(gold)-{0}),average="macro",zero_division=0)
        row={"epoch":epoch+1,"train_loss":sum(losses)/len(losses),"validation_bio_weighted_f1":wf,"validation_bio_macro_f1":mf,"elapsed_seconds":time.time()-start}
        history.append(row);print(json.dumps(row),flush=True)
        if wf>best:
            best=wf;model.save_pretrained(dest,safe_serialization=True);tokenizer.save_pretrained(dest)
        write_json(root/"results/training.json",{"base_model":BASE,"seed":12012,"device":device,"hardware":torch.cuda.get_device_name(0) if device=="cuda" else "CPU","configuration":vars(args),"train_windows":len(train),"validation_windows":len(val),"trainable_parameters":sum(p.numel() for p in model.parameters() if p.requires_grad),"selection":"maximum validation BIO weighted F1; test not used", "history":history,"best_validation_f1":best,"train_sha256":hashlib.sha256((root/"data/train.jsonl").read_bytes()).hexdigest(),"validation_sha256":hashlib.sha256((root/"data/validation.jsonl").read_bytes()).hexdigest()})
    write_json(dest/"provenance.json",json.loads((root/"results/training.json").read_text(encoding="utf-8")))


if __name__=="__main__":main()
