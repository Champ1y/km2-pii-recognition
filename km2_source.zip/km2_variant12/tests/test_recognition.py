import pytest
from pii.schema import Span,to_bio,from_bio,resolve,validate_spans
from pii.rules import structured,valid_inn,valid_card,valid_ogrnip
from pii.evaluation import evaluate

def test_metrics_count_false_positives_and_misses():
    rows = [{'id': 'x', 'source': 'unit', 'text': 'Иван и Пётр', 'entities': [['NAME', 0, 4], ['NAME', 7, 11]]}]
    m, _ = evaluate(rows, [[Span('NAME', 0, 4), Span('NAME', 5, 6)]])
    assert m['per_attribute']['NAME']['precision'] == 0.5
    assert m['per_attribute']['NAME']['recall'] == 0.5
    assert m['per_attribute']['NAME']['f1'] == 0.5

def test_bio_roundtrip_and_overlap_priority():
    text = 'Почта ivan.petrov@example.org.'
    e = structured(text)[0]
    accepted = resolve([Span('NAME', e.start, e.start + 4), e])
    assert accepted == [e]
    tok, tags = to_bio(text, accepted)
    assert [s.triple() for s in from_bio(tok, tags)] == [e.triple()]
    assert set((t for t in tags if t != 'O')) == {'B-EMAIL', 'I-EMAIL'}

@pytest.mark.parametrize('value,label', [('770698959438', 'INN'), ('4561 2612 1234 5467', 'BANK_CARD'), ('304500116000157', 'OGRNIP')])
def test_checksums_reject_corruption(value, label):
    checker = {'INN': valid_inn, 'BANK_CARD': valid_card, 'OGRNIP': valid_ogrnip}[label]
    assert checker(value)
    corrupted = value[:-1] + str((int(value[-1]) + 1) % 10)
    assert not checker(corrupted)

def test_ip_sentence_punctuation_and_invalid_ip():
    assert ['IP', 4, 15] in [s.triple() for s in structured('IP: 192.168.1.2.')]
    assert not [s for s in structured('IP: 999.168.1.2.') if s.label == 'IP']
    assert [s for s in structured('IP: 2001:db8::1.') if s.label == 'IP']

def test_invalid_ogrnip_is_not_reinterpreted_as_a_card():
    value = next(('32477' + str(i).zfill(10) for i in range(1000) if valid_card('32477' + str(i).zfill(10)) and (not valid_ogrnip('32477' + str(i).zfill(10)))))
    assert not structured('ОГРНИП: ' + value)

@pytest.mark.parametrize('spans', [[['NAME', -1, 4]], [['NAME', 0, 100]], [['NO', 0, 1]], [['NAME', True, 2]], [['NAME', 0, 3], ['SURNAME', 2, 4]]])
def test_invalid_intervals_rejected(spans):
    with pytest.raises(ValueError):
        validate_spans('Иван', spans)
